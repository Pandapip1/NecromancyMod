﻿using HarmonyLib;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Pandapip1s_Necromancy_mod
{
	[HarmonyPatch(typeof(EndGameManager), nameof(EndGameManager.SetEverythingUp))]
    public static class EndGameCutscenePatch
    {
        public static void Postfix(EndGameManager __instance)
        {
            if (!TempData.DidHumansWin(TempData.EndReason))
            {
                __instance.WinText.Color = Color.magenta;
                __instance.BackgroundBar.material.color = Color.green;
            }
        }
    }
}
