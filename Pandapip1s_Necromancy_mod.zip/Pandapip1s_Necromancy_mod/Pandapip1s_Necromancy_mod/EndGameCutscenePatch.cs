﻿using HarmonyLib;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Pandapip1s_Necromancy_mod
{
	[HarmonyPatch(typeof(EndGameManager), nameof(EndGameManager.SetEverythingUp))]
    public static class EndGameCutscenePatch
    {
        public static bool Prefix(EndGameManager __instance)
        {
            // Modify TempData.winners
            return true;
        }
        public static void Postfix(EndGameManager __instance)
        {
            if (TempData.DidHumansWin(TempData.EndReason))
            {
                __instance.WinText.Text = "Crewmate Victory";
                __instance.WinText.Color = Palette.CrewmateBlue;
                __instance.BackgroundBar.material.color = Palette.CrewmateBlue;
            } else
            {
                __instance.WinText.Text = "Necromancer Victory";
                __instance.WinText.Color = Color.magenta;
                __instance.BackgroundBar.material.color = Color.green;
            }
        }
    }
}
