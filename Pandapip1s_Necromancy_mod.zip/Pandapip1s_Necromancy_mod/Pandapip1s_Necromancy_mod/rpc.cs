﻿using HarmonyLib;
using Hazel;
using System;

namespace Pandapip1s_Necromancy_mod
{
    enum CustomRPC
    {
        SetGhoul = 150,
        Zap = 151,
        KillPlayer = 152
    }
    [HarmonyPatch(typeof(PlayerControl), nameof(PlayerControl.HandleRpc))]
    class HandleRpcPatch
    {
        static void Postfix(byte HKHMBLJFLMC, MessageReader ALMCIJKELCP)
        {
            byte packetId = HKHMBLJFLMC;
            MessageReader reader = ALMCIJKELCP;
            switch (packetId)
            {
                case (byte)CustomRPC.SetGhoul:
                    GhoulManager.ghouls.Add(reader.ReadByte());
                    break;
                case (byte)CustomRPC.Zap:
                    GhoulManager.ghouls.Remove(reader.ReadByte());
                    break;
                case (byte)CustomRPC.KillPlayer:
                    if (reader.ReadByte() == PlayerControl.LocalPlayer.PlayerId)
                    {
                        PlayerControl.LocalPlayer.RpcMurderPlayer(PlayerControl.LocalPlayer);
                    }
                    break;
            }
        }
    }
}