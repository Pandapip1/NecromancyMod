﻿using HarmonyLib;
using System.Collections.Generic;
using System;
using UnityEngine;

namespace Pandapip1s_Necromancy_mod
{
    [HarmonyPatch(typeof(IntroCutscene.CoBegin__d), nameof(IntroCutscene.CoBegin__d.MoveNext))]
    public static class IntroCutscenePatch
    {
        public static void Postfix(ref IntroCutscene.CoBegin__d __instance)
        {
            GhoulManager.ghouls.Clear();
            IntroCutscene scene = __instance.__this;
            if (PlayerControl.LocalPlayer.Data.IsImpostor)
            {
                scene.Title.Text = "Necromancer";
                scene.Title.Color = Color.magenta;
                scene.ImpostorText.Text = "Kill all the [00FFFFFF]Crewmates";
                scene.BackgroundBar.material.color = Color.green;
            } else
            {
                scene.Title.Text = "Crewmate";
                scene.Title.Color = Palette.CrewmateBlue;
                scene.ImpostorText.Text = "Finish all the tasks or sus out the [FF00FFFF]Necromancers";
                scene.BackgroundBar.material.color = Palette.CrewmateBlue;
            }
        }
    }
}