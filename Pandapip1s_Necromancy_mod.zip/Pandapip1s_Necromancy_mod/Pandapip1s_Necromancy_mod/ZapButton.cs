﻿using HarmonyLib;
using System;
using UnityEngine;
using Reactor.Button;
using Hazel;

namespace Pandapip1s_Necromancy_mod
{
    [HarmonyPatch(typeof(HudManager), nameof(HudManager.Start))]
    public static class ZapButtonStartPatch
    {
        public static CooldownButton btn;
        public static void Postfix(HudManager __instance)
        {
            btn = new CooldownButton(
                () =>
                {
                    btn.Timer = btn.MaxTimer;
                    foreach (int ghoul in GhoulManager.ghouls)
                    {
                        foreach (PlayerControl p in PlayerControl.AllPlayerControls)
                        {
                            if (p.PlayerId == ghoul)
                            {
                                float kd = GameOptionsData.KillDistances[Mathf.Clamp(PlayerControl.GameOptions.KillDistance, 0, 2)]*3;
                                Vector2 pos1 = p.GetTruePosition();
                                Vector2 pos2 = PlayerControl.LocalPlayer.GetTruePosition();
                                if ((pos1.x - pos2.x) * (pos1.x - pos2.x) + (pos1.y - pos2.y) * (pos1.y - pos2.y) < kd*kd)
                                {
                                    MessageWriter writer = AmongUsClient.Instance.StartRpcImmediately(PlayerControl.LocalPlayer.NetId, (byte)CustomRPC.Zap, Hazel.SendOption.None, -1);
                                    writer.Write(p.PlayerId);
                                    AmongUsClient.Instance.FinishRpcImmediately(writer);
                                    GhoulManager.ghouls.Remove(p.PlayerId);
                                }
                                return;
                            }
                        }
                    }
                },
                15f,
                Properties.Resources.zap_v2,
                new Vector2(0f, 0f),
                () =>
                {
                    return AmongUsClient.Instance.GameState == InnerNetClient.GameStates.Started && !PlayerControl.LocalPlayer.Data.IsDead;
                },
                __instance
            );
        }
    }
    [HarmonyPatch(typeof(PlayerControl), nameof(PlayerControl.FixedUpdate))]
    public static class ZapBtnHighlightPlayersPatch
    {
        public static void Postfix(PlayerControl __instance)
        {
            GameData.PlayerInfo data = __instance.Data;
            if (PlayerControl.LocalPlayer && PlayerControl.LocalPlayer.Data != null && !PlayerControl.LocalPlayer.Data.IsImpostor)
            {
                foreach (PlayerControl p in PlayerControl.AllPlayerControls)
                {
                    Vector2 pos1 = p.GetTruePosition();
                    Vector2 pos2 = PlayerControl.LocalPlayer.GetTruePosition();
                    if (p.Data.IsDead)
                    {
                        float kd = GameOptionsData.KillDistances[Mathf.Clamp(PlayerControl.GameOptions.KillDistance, 0, 2)] * 3;
                        if (GhoulManager.ghouls.Contains(p.PlayerId) && (pos1.x - pos2.x) * (pos1.x - pos2.x) + (pos1.y - pos2.y) * (pos1.y - pos2.y) < kd*kd)
                        {
                            p.myRend.material.SetFloat("_Outline", 1);
                            p.myRend.material.SetColor("_OutlineColor", Color.yellow);
                            p.myRend.material.SetColor("_AddColor", Color.yellow);
                        }
                        else
                        {
                            p.myRend.material.SetFloat("_Outline", 0);
                            p.myRend.material.SetColor("_OutlineColor", Color.yellow);
                            p.myRend.material.SetColor("_AddColor", Color.clear);
                        }
                    }
                }
            }
        }
    }
}