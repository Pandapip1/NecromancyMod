﻿using HarmonyLib;
using Hazel;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace Pandapip1s_Necromancy_mod
{
    static class GhoulManager
    {
        internal static List<int> ghouls = new List<int>();
        internal static float ghoulcd = 0;
    }
    [HarmonyPatch(typeof(PlayerPhysics), nameof(PlayerPhysics.FixedUpdate))]
    class GhoulMovementPatch
    {
        static bool Prefix(PlayerPhysics __instance)
        {
            if (__instance.AmOwner && PlayerControl.LocalPlayer.CanMove && GameData.Instance && PlayerControl.LocalPlayer.Data.IsDead && GhoulManager.ghouls.Contains(PlayerControl.LocalPlayer.PlayerId))
            {
                Vector2 pos = Vector2.zero;
                float closestpos = 99999999;
                PlayerControl closestplayer = null;
                foreach (PlayerControl p in PlayerControl.AllPlayerControls)
                {
                    Vector2 pos1 = p.GetTruePosition();
                    Vector2 pos2 = PlayerControl.LocalPlayer.GetTruePosition();
                    if (!p.Data.IsDead && !p.Data.IsImpostor && (pos1.x - pos2.x) * (pos1.x - pos2.x) + (pos1.y - pos2.y) * (pos1.y - pos2.y) < closestpos)
                    {
                        pos = pos1;
                        closestpos = (pos1.x - pos2.x) * (pos1.x - pos2.x) + (pos1.y - pos2.y) * (pos1.y - pos2.y);
                        closestplayer = p;
                    }
                }
                if (!pos.Equals(Vector2.zero))
                {
                    Vector2 vector = pos - new Vector2(__instance.transform.position.x, __instance.transform.position.y);
                    float kd = GameOptionsData.KillDistances[Mathf.Clamp(PlayerControl.GameOptions.KillDistance, 0, 2)];
                    if (vector.sqrMagnitude <= kd*kd && GhoulManager.ghoulcd <= 0)
                    {
                        GhoulManager.ghoulcd = .5f;
                        PlayerControl.LocalPlayer.RpcMurderPlayer(closestplayer);
                    }
                    __instance.body.velocity = vector.normalized * __instance.TrueGhostSpeed;
                }
                return false;
            }
            return true;
        }
    }
    [HarmonyPatch(typeof(PlayerControl), nameof(PlayerControl.MurderPlayer))]
    static class GhoulKillPatch
    {
        static bool Prefix(PlayerControl __instance, out bool[] __state)
        {
            __state = new bool[] { __instance.Data.IsImpostor, __instance.Data.IsDead };
            if (GhoulManager.ghouls.Contains(__instance.PlayerId))
            {
                __instance.Data.IsImpostor = true;
                __instance.Data.IsDead = false;
            }
            return true;
        }

        static void Postfix(PlayerControl __instance, bool[] __state)
        {
            __instance.Data.IsImpostor = __state[0];
            __instance.Data.IsDead = __state[1];
        }
    }
    [HarmonyPatch(typeof(MeetingHud), nameof(MeetingHud.Start))]
    static class ClearGhoulsOnMeeting
    {
        static void Prefix()
        {
            GhoulManager.ghouls.Clear();
        }
    }
    [HarmonyPatch(typeof(HudManager), nameof(HudManager.Update))]
    public static class GhoulCooldownPatch
    {
        public static void Postfix(HudManager __instance)
        {
            if (GhoulManager.ghoulcd > 0)
            {
                GhoulManager.ghoulcd -= Time.deltaTime;
            }
        }
    }
}
