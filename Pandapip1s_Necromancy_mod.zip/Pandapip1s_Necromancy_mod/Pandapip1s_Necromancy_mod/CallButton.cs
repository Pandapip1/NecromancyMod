﻿using HarmonyLib;
using System;
using UnityEngine;
using Buttons;
using Hazel;

namespace Pandapip1s_Necromancy_mod
{
    [HarmonyPatch(typeof(HudManager), nameof(HudManager.Start))]
    public static class TargetButtonStartPatch
    {
        public static CooldownButton btn;
        public static void Postfix(HudManager __instance)
        {
            btn = new CooldownButton(
                () =>
                {
                    btn.Timer = btn.MaxTimer;
                    foreach (PlayerControl p in PlayerControl.AllPlayerControls)
                    {
                        if (p.Data.IsDead && !GhoulManager.ghouls.Contains(p.PlayerId))
                        {
                            float kd = GameOptionsData.KillDistances[Mathf.Clamp(PlayerControl.GameOptions.KillDistance, 0, 2)]*2;
                            Vector2 pos1 = p.GetTruePosition();
                            Vector2 pos2 = PlayerControl.LocalPlayer.GetTruePosition();
                            if ((pos1.x - pos2.x) * (pos1.x - pos2.x) + (pos1.y - pos2.y) * (pos1.y - pos2.y) < kd*kd)
                            {
                                MessageWriter writer = AmongUsClient.Instance.StartRpcImmediately(PlayerControl.LocalPlayer.NetId, (byte)CustomRPC.SetGhoul, Hazel.SendOption.None, -1);
                                writer.Write(p.PlayerId);
                                AmongUsClient.Instance.FinishRpcImmediately(writer);
                                GhoulManager.ghouls.Add(p.PlayerId);
                            }
                        }
                    }
                },
                20f,
                Properties.Resources.Call_Ghost_v2,
                0.25f,
                new Vector2(0f, 1.5f),
                CooldownButton.Category.OnlyImpostor,
                __instance
            );
        }
    }
    [HarmonyPatch(typeof(PlayerControl), nameof(PlayerControl.FixedUpdate))]
    public static class CallBtnHighlightPlayersPatch
    {
        public static void Postfix(PlayerControl __instance)
        {
            GameData.PlayerInfo data = __instance.Data;
            if (PlayerControl.LocalPlayer && PlayerControl.LocalPlayer.Data != null && PlayerControl.LocalPlayer.Data.IsImpostor)
            {
                foreach (PlayerControl p in PlayerControl.AllPlayerControls)
                {
                    Vector2 pos1 = p.GetTruePosition();
                    Vector2 pos2 = PlayerControl.LocalPlayer.GetTruePosition();
                    if (p.Data.IsDead)
                    {
                        float kd = GameOptionsData.KillDistances[Mathf.Clamp(PlayerControl.GameOptions.KillDistance, 0, 2)] * 2;
                        if (!GhoulManager.ghouls.Contains(p.PlayerId) && (pos1.x - pos2.x) * (pos1.x - pos2.x) + (pos1.y - pos2.y) * (pos1.y - pos2.y) < kd*kd)
                        {
                            p.myRend.material.SetFloat("_Outline", 1);
                            p.myRend.material.SetColor("_OutlineColor", Color.green);
                            p.myRend.material.SetColor("_AddColor", Color.green);
                        } else
                        {
                            p.myRend.material.SetFloat("_Outline", 0);
                            p.myRend.material.SetColor("_OutlineColor", Color.green);
                            p.myRend.material.SetColor("_AddColor", Color.clear);
                        }
                    }
                }
            }
        }
    }
}