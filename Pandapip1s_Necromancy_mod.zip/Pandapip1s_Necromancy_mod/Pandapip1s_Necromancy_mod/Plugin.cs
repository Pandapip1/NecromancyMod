﻿using BepInEx;
using BepInEx.IL2CPP;
using BepInEx.Logging;
using HarmonyLib;
using Reactor;
using System.IO;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Pandapip1s_Necromancy_mod
{
    [BepInPlugin(Id)]
    [BepInProcess("Among Us.exe")]
    [BepInDependency(ReactorPlugin.Id)]
    public class NecromancyPlugin : BasePlugin
    {
        public static NecromancyPlugin Instance;

        public const string Id = "tk.pandapip1.necromancymod";

        public Harmony Harmony { get; } = new Harmony(Id);

        internal ManualLogSource debuglog = null;

        public override void Load()
        {
            Instance = this;
            debuglog = BepInEx.Logging.Logger.CreateLogSource("NecromanyMod_Debug");
            Harmony.PatchAll();
        }

        [HarmonyPatch(typeof(PlayerControl), nameof(PlayerControl.FixedUpdate))]
        public static class SeeDeadPlayersPatch
        {
            public static void Postfix(PlayerControl __instance)
            {
                GameData.PlayerInfo data = __instance.Data;
                if (data.IsDead && PlayerControl.LocalPlayer && PlayerControl.LocalPlayer.Data != null)
                {
                    __instance.Visible = PlayerControl.LocalPlayer.Data.IsDead || PlayerControl.LocalPlayer.Data.IsImpostor || GhoulManager.ghouls.Contains(__instance.PlayerId);
                    if (GhoulManager.ghouls.Contains(__instance.PlayerId))
                    {
                        __instance.nameText.Color = Color.green;
                    } else if (data.IsImpostor && PlayerControl.LocalPlayer.Data.IsImpostor)
                    {
                        __instance.nameText.Color = Palette.ImpostorRed;
                    } else
                    {
                        __instance.nameText.Color = Palette.White;
                    }
                }
            }
        }
    }
}
